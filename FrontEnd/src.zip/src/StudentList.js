import React, { useEffect, useState } from "react";
import axios from "axios";
const StudentDetail = (props) => {
  return (
    <ul class="list-group">
      <labe><strong>ID:</strong></labe>
      <li class="list-group-item">{props.student._id}</li>
      <label><strong>Full Name:</strong></label>
      <li class="list-group-item">{props.student.name}</li>
      <label><strong>Age:</strong></label>
      <li class="list-group-item">{props.student.age}</li>
      <label><strong>Gender:</strong></label>
      <li class="list-group-item">{props.student.gender}</li>
      <label><strong>Final Score:</strong></label>
      <li class="list-group-item">{props.student.score}</li>
      <label><strong>Registered On:</strong></label>
      <li class="list-group-item">{props.student.registeredOn}</li>
    </ul>
  );
};

const StudentUpdate = (props) => {
 
  const [_id, setId] = useState();
  const [name, setName] = useState(props.student.name);
  const [age, setAge] = useState(props.student.age);
  const [gender, setGender] = useState(props.student.gender);
  const [score, setScore] = useState(props.student.score);
  
  const updateStudent = async () => {
    if (name === "" && age === "" && gender === "" && score === "") {
      alert("Please enter name, age, gender and score");
    } else {
      await axios
        .put("http://localhost:3000/Student", {
        
          name: name,
          age: age,
          gender: gender,
          score: score
        })
        .then(function (response) {
          alert("Updated Successfully");
          window.location.reload();
          console.log(response);
        })
        .catch(function (error) {
          alert("Error Updating Student detail");
          console.log(error);
        });
    }
  };
 
  return (
    <div> 
        <div class="row">
          <div className="col-md-12">
            <div class="row">
              <div class="form-floating">
                <input
                  type="text"
                  class="form-control"
                  type="hidden"
                  value = {props.student._id}
                  onChange={(e) => setId(e.target.value)}
              
                />
              </div>
              <div class="form-floating">
                <input
                  type="text"
                  class="form-control"
                  value = {name}
                  onChange={(e) => setName(e.target.value)}
                  
                />
              </div>
              <div class="form-floating">
                <input
                  type="number"
                  min="18"
                  max="40"
                  required
                  class="form-control"
                  value = {age}
                  onChange={(e) => setAge(e.target.value)}
                />
              </div>
              <div class="form-floating">
                <input
                  list="browse"
                  type="text"
                  required
                  class="form-control"
                  value = {gender}
                  onChange={(e) => setGender(e.target.value)}
                />
                <datalist id="browse">
                  <option value="Male"></option>
                  <option value="Female"></option>
                </datalist>
              </div>
              <div class="form-floating">
                <input
                  type="number"
                  min="0"
                  max="100"
                  required
                  class="form-control"
                  value = {score}
                  onChange={(e) => setScore(e.target.value)}
                />
              </div>

              <div class="col text-right">
                <button
                  className="btn btn-success"
                  onClick={() => updateStudent()}
                >
                Update
                </button>

               
              </div>
            </div>
          </div>
        </div>
      
    </div>
  );
};




export const StudentList = () => {
  const [formToggle, setFormToggle] = useState(false);
  const [displayDetail, setDisplayDetail] = useState(false);
  const [displayDetailView, setDisplayDetailView] = useState(false);
  const [studentList, setStudentList] = useState();
  const [selectedStudent, setSelectedStudent] = useState();
 
  const fetchStudentList = async () => {
    await axios
      .get(`http://localhost:3000/student`, {
        headers: { "Access-Control-Allow-Origin": "*" }
      })
      .then(function (response) {
        // handle success
        setStudentList(response.data);
        // setWeatherData(response.data);
        console.log(response);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      })
      .then(function () {
        // always executed
      });
  };

  useEffect(() => {
    fetchStudentList();
  }, []);

  // const studentStatus = async score =>
  //   await axios
  //         .get(`http://localhost:3000/student/${score}`);
          

  // const updateStudent = async student => {
  //   await axios
  //   .put(`http://localhost:3000/Student/student._id`,)
  //   .then(function (response) {
  //     alert("saved Successfully");
  //     window.location.reload();
  //     console.log(response);
  //   })
  //   .catch(function (error) {
  //     alert("Error updating Student detail");
  //     console.log(error);
  //   });
  // };

  const deleteStudent = async _id => {
      await axios.delete(`http://localhost:3000/student/${_id}`);  
      fetchStudentList();
  };
  

  return (
    <div>
      <div class="row">
        <div className="col-md-8">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Score</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>

              
              {studentList &&
                studentList.map((item, index) => {
                  
                 return (
                    <tr  className={item.score < 40 ?"red": 'green' }>
                      <th scope="row">{index + 1}</th>
                      <td>{item._id}</td>
                      <td>{item.name}</td>
                      <td>{item.score}</td>
                      <td>{(item.score < 40) ? <span>Fail</span>: <span>Pass</span>}</td>
                      <td>
                        <button
                          className="btn btn-primary"
                          onClick={() => {
                            setSelectedStudent(item);
                            setDisplayDetail(true);
                          }}
                        >
                          View
                        </button>
                        <button
                          className="btn btn-danger"

                          onClick={() => {
                            //StudentUpdate(item);
                            setSelectedStudent(item);
                            setDisplayDetailView(true);

                            // setDisplayDetail(true);
                            // updateStudent(item._id);
                          }}
                        >
                          Edit
                        </button>
                        <button
                          className="btn btn-primary"
                          onClick={() => {
                            deleteStudent(item._id);
                          }}
                        >
                          delete
                        </button>
                        
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
        <div className="col-md-4">
          <h2>Details</h2>

          {displayDetail && (
            <>
              <StudentDetail student={selectedStudent} />
              <button
                className="btn btn-sm btn-warning"
                onClick={() => setDisplayDetail(!displayDetail)}
              >
                Close
              </button>
            </>
          )}
        </div>

        
        <div className="col-md-4">
          <h2>Edit Users</h2>

          {displayDetailView && (
            <>
              <StudentUpdate  student={selectedStudent} />
              <button
                className="btn btn-sm btn-warning"
                onClick={() => setDisplayDetailView(!displayDetailView)}
              >
                Close
              </button>
            </>
          )}
        </div>



      </div>
      <br />
    </div>
  );
};
