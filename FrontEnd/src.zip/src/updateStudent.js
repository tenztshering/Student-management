import React, { useState } from "react";
import axios from "axios";


export const UpdateStudent = () => {
  const [formToggle, setFormToggle] = useState(false);

  const [name, setName] = useState();
  const [age, setAge] = useState();
  const [gender, setGender] = useState();
  const [score, setScore] = useState();
  const saveStudent = async () => {
    if (name === "" && age === "" && gender === "" && score === "") {
      alert("Please enter name, age, gender and score");
    } else {
      await axios
        .post("http://localhost:3000/Student", {
          name: name,
          age: age,
          gender: gender,
          score: score
        })
        .then(function (response) {
          alert("saved Successfully");
          window.location.reload();
          console.log(response);
        })
        .catch(function (error) {
          alert("Error saving Student detail");
          console.log(error);
        });
    }
  };

  return (
    <div>
      <div class="row">
        <div className="col-md-12">
          <div
            style={{
              textAlign: "right"
            }}
          >
            <button
              className="btn btn-warning"
              onClick={() => setFormToggle(true)}
            >
             Edit
            </button>
          </div>
        </div>
      </div>
      <br />
      {formToggle && (
        <div class="row">
          <div className="col-md-12">
            <div class="row">
              <div class="col">
                <input
                  type="text"
                  class="form-control"
                  
                  placeholder="Full Name"
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div class="col">
                <input
                  type="number"
                  min="18"
                  max="40"
                  class="form-control"
                  placeholder="Age"
                  onChange={(e) => setAge(e.target.value)}
                />
              </div>
              <div class="col">
                <input
                  list="browse"
                  type="text"
                  class="form-control"
                  placeholder="Gender"
                  onChange={(e) => setGender(e.target.value)}
                />
                <datalist id="browse">
                  <option value="Male"></option>
                  <option value="Female"></option>
                </datalist>
              </div>
              <div class="col">
                <input
                  type="number"
                  min="0"
                  max="100"
                  class="form-control"
                  placeholder="Final Score"
                  onChange={(e) => setScore(e.target.value)}
                />
              </div>
              <div class="col text-right">
                <button
                  className="btn btn-success"
                  onClick={() => saveStudent()}
                >
                 Update
                </button>

                <button
                  className="btn btn-danger"
                  onClick={() => setFormToggle(!formToggle)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};